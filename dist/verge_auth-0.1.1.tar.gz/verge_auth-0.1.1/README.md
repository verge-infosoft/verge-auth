🔐 Verge Auth
Plug-and-Play Central Authentication for FastAPI & Microservices

Verge Auth is a lightweight, production-ready authentication SDK that allows any FastAPI or microservice application to connect with a central authentication server using a single line of code.

It is built for teams creating microservices, SaaS platforms, and enterprise-grade applications where authentication must be secure, centralized, and reusable.

⚠️ Note: Verge Auth SDK requires a Verge Auth Server to function.
This package is the client-side integration layer only.

🔧 Environment Configuration

Add these variables to your .env file before running your service:

# Database
DATABASE_URL=your_database_url

# Verge Auth Server URLs
AUTH_INTROSPECT_URL=https://auth.yourdomain.com/introspect
AUTH_LOGIN_URL=https://auth.yourdomain.com/auth/login

# SDK Credentials

# Free Tier
VERGE_CLIENT_ID=your_company_name
VERGE_CLIENT_SECRET=free-tier

# Paid Tier (Provided by Verge Auth Team)
# VERGE_CLIENT_ID=client_abc123
# VERGE_CLIENT_SECRET=secret_xyz789


⚠️ Free-tier users must keep VERGE_CLIENT_SECRET=free-tier

✨ Core Features

✅ Single-line integration
✅ Centralized authentication
✅ Token introspection
✅ Role-based access control (RBAC)
✅ Cookie & Header JWT support
✅ Super Admin / Admin / User flows
✅ Plug-and-play middleware

🧠 How It Works

When a user tries to access your service:

Request hits your microservice

Verge Auth middleware intercepts it

Token is sent to Verge Auth Server

Server validates session and role

Access granted or redirected

+-------------------+
|   Your Service    |
+-------------------+
         |
         |  Validate Token
         v
+-------------------+
| Verge Auth Server |
+-------------------+

📦 Installation
pip install verge-auth

install from GitHub:
pip install git+https://github.com/verge-infosoft/verge-auth.git

⚡ Quick Start
from fastapi import FastAPI
from verge_auth import add_central_auth

app = FastAPI()

add_central_auth(app)


That’s it ✅
Your service is now protected.

🔐 Token Handling

The middleware automatically:

Reads tokens from Authorization: Bearer <token>

Falls back to cookies for browser-based auth

Redirects to login if unauthenticated

Validates token using central auth server

🧑‍💼 Role-Based Access

User context is injected automatically:

request.state.user
request.state.roles


Use this data to build role-based guards in your routes.

🧩 Role Flow
Role	Behavior
Super Admin	Full access + admin dashboard
Admin	Full access except super-admin privileges
User	Redirected to service UI
🧱 Architecture
Client → Microservice → Verge Auth Middleware → Auth Server
                                     ↓
                              Verified / Rejected

🚀 Roadmap

✅ FastAPI Support
🔜 Django / Flask Support
🔜 Node.js SDK
🔜 Go SDK
🔜 Dashboard UI
🔜 API Gateway Mode

📌 License

MIT License © 2025 Verge Infosoft

👨‍💻 Maintained By

Verge Infosoft
📧 contactus@vergeinfosoft.com

🌐 https://vergeinfosoft.com